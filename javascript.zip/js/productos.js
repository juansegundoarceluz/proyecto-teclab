const productos = [
    {   
        id: "la",
        imagen: "🍌",
        nombre: "Bananas",
        precio: 220
    },
    {   
        id : "le",
        imagen: "🍎",
        nombre: "Manzanas",
        precio: 200
    },
    {   
        id: "li",
        imagen: "🥝",
        nombre: "Kiwis",
        precio: 280
    },
    {   
        id: "lo",
        imagen: "🍈",
        nombre: "Melón",
        precio: 350
    },
    {   
        id:"lu",
        imagen: "🍍",
        nombre: "Piñas",
        precio: 320
    },
    {   
        id:"ab",
        imagen: "🍅",
        nombre: "Tomates",
        precio: 140
    },
    {   
        id: "cd",
        imagen: "🥥",
        nombre: "Cocos",
        precio: 270
    },
    {   
        id: "ef",
        imagen: "🍉",
        nombre: "Sandias",
        precio: 200
    },
    {   
        id: "gi",
        imagen: "🍑",
        nombre: "Duraznos",
        precio: 310
    },
    {   
        id: "jk",
        imagen: "🫐",
        nombre: "Arandanos",
        precio: 650
    },
    {   id:"lm", 
        imagen: "🥭",
        nombre: "Mango",
        precio: 290
    },
    {   id:"mn",
        imagen: "🍇",
        nombre: "Uvas",
        precio: 700
    },
    {   
        id:"op",
        imagen: "🍐",
        nombre: "Peras",
        precio: 320
    },
    {   
        id:"qr",
        imagen: "🍒",
        nombre: "Cerezas",
        precio: 1100
    },
    {    
        id:"st",
        imagen: "🍓",
        nombre: "Frutillas",
        precio: 600
    },
    {   
        id:"uv",
        imagen: "🍋",
        nombre: "Limones",
        precio: 260
    }
]
 
function retornarCardHTML(producto) {
    const cardHTML = `
      <div class="card">
         
        <h2>${producto.nombre}</h2>
        <p>Precio: ${producto.precio}</p>
        <button id="${producto.id}">Agregar al carrito</button>
      </div>
    `;
    return cardHTML;
  }
  function cargarProductos(array) {
    const container = document.querySelector('.container');
  
    array.forEach(producto => {
      const cardHTML = retornarCardHTML(producto);
      container.innerHTML += cardHTML;
    });
  }
 cargarProductos(productos)