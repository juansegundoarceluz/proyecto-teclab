const productosFav= []

const agregarAFavs = (productoID)=>{
    if (productoID > 0){
        const resultado = productos.find(producto=> producto.id === parseInt
            (productoID))
        if (resultado !== undefined){
            productosFav.push(resultado)
            console.table(productosFav)
        }else{
            console.warn("no se encontro el producto con tal codigo");
            
        }
    }
    
}